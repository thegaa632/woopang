package com.standout.sopang.mypage.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MyPageDTO {
    private String member_id;
    private String beginDate;
    private String endDate;



}
